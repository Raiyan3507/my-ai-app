package com.example.model

/**
 * Represents a vibration pattern with timings in milliseconds and optional amplitudes (0-255).
 */
data class VibrationPattern(
    val id: String,
    val name: String,
    val subtitle: String,
    val timings: LongArray,
    val amplitudes: IntArray = intArrayOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as VibrationPattern
        return id == other.id
    }

    override fun hashCode(): Int {
        return id.hashCode()
    }
}

object PredefinedPatterns {
    val MUTTHI_SIGNATURE = VibrationPattern(
        id = "mutthi_sig",
        name = "Mutthi Signature",
        subtitle = "Triple surge: soft, medium, powerful",
        timings = longArrayOf(0, 100, 70, 180, 70, 350),
        amplitudes = intArrayOf(0, 120, 0, 190, 0, 255)
    )

    val BANGLA_BOL = VibrationPattern(
        id = "bangla_bol",
        name = "Bengali Dhol Rhythm",
        subtitle = "Rhythmic tap pattern inspired by festival drums",
        timings = longArrayOf(0, 140, 60, 70, 60, 200, 80, 280),
        amplitudes = intArrayOf(0, 220, 0, 150, 0, 240, 0, 255)
    )

    val HEARTBEAT = VibrationPattern(
        id = "heartbeat",
        name = "Resonant Heartbeat",
        subtitle = "Double pulse mimics a living pulse",
        timings = longArrayOf(0, 90, 100, 90, 350),
        amplitudes = intArrayOf(0, 180, 0, 240, 0)
    )

    val STACCATO = VibrationPattern(
        id = "staccato",
        name = "Staccato Tremor",
        subtitle = "Rapid burst vibration sequence",
        timings = longArrayOf(0, 45, 45, 45, 45, 45, 45, 45, 45, 160),
        amplitudes = intArrayOf(0, 200, 0, 200, 0, 200, 0, 200, 0, 255)
    )

    val COSMIC_SURGE = VibrationPattern(
        id = "cosmic_surge",
        name = "Cosmic Surge",
        subtitle = "Smooth accelerating sensory wave",
        timings = longArrayOf(0, 220, 80, 420),
        amplitudes = intArrayOf(0, 160, 0, 255)
    )

    val ALL = listOf(
        MUTTHI_SIGNATURE,
        BANGLA_BOL,
        HEARTBEAT,
        STACCATO,
        COSMIC_SURGE
    )
}

data class TriggerHistoryItem(
    val id: Long = System.currentTimeMillis(),
    val timestamp: String,
    val patternName: String,
    val textSpoken: String
)

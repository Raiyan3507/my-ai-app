package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Radiant Magenta & Electric Violet
val VioletDark = Color(0xFF0F0B21)
val VioletSurface = Color(0xFF181335)
val VioletSurfaceVariant = Color(0xFF241C47)
val VioletBorder = Color(0xFF392E6E)

val PrimaryNeon = Color(0xFFFF2E93)
val PrimaryNeonGlow = Color(0xFFFF6EB4)
val SecondaryCyan = Color(0xFF00F0FF)
val SecondaryCyanDark = Color(0xFF0094A0)
val AccentGold = Color(0xFFFFB800)
val AccentEmerald = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextTertiary = Color(0xFF94A3B8)

// Light theme fallback colors
val LightBackground = Color(0xFFF7F5FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDE9FE)
val LightPrimary = Color(0xFF9333EA)
val LightSecondary = Color(0xFF0284C7)

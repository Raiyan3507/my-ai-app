package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Vibration
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MutthiDisplayCard
import com.example.ui.components.ResonantButton
import com.example.ui.components.SpeechControlsCard
import com.example.ui.components.TriggerHistoryCard
import com.example.ui.components.VibrationSelector
import com.example.ui.theme.AccentGold
import com.example.ui.theme.PrimaryNeon
import com.example.ui.theme.SecondaryCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletBorder
import com.example.ui.theme.VioletDark
import com.example.ui.theme.VioletSurface
import com.example.ui.theme.VioletSurfaceVariant
import com.example.ui.viewmodel.MutthiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MutthiMahabiScreen(
    viewModel: MutthiViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("mutthi_mahabi_screen"),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = VioletDark,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(PrimaryNeon)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Mutthi Mahabi",
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "মুটঠি মাহাবি",
                                color = SecondaryCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    // Voice Mute Toggle
                    IconButton(
                        onClick = { viewModel.toggleVoiceMute() },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (uiState.isVoiceMuted) VioletSurfaceVariant else SecondaryCyan.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("toggle_voice_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isVoiceMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                            contentDescription = if (uiState.isVoiceMuted) "Unmute Voice" else "Mute Voice",
                            tint = if (uiState.isVoiceMuted) TextSecondary else SecondaryCyan
                        )
                    }

                    // Vibration Toggle
                    IconButton(
                        onClick = { viewModel.toggleVibrationMute() },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (uiState.isVibrationMuted) VioletSurfaceVariant else AccentGold.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("toggle_vibration_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isVibrationMuted) Icons.Outlined.Vibration else Icons.Default.Vibration,
                            contentDescription = if (uiState.isVibrationMuted) "Enable Vibration" else "Disable Vibration",
                            tint = if (uiState.isVibrationMuted) TextSecondary else AccentGold
                        )
                    }

                    // Reset Button
                    if (uiState.isTriggered) {
                        IconButton(
                            onClick = { viewModel.resetState() },
                            modifier = Modifier.testTag("reset_state_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset State",
                                tint = TextSecondary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = VioletDark,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            VioletDark,
                            VioletSurface,
                            VioletDark
                        )
                    )
                ),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 620.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp)
                    .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                // Hero subtitle instruction
                Text(
                    text = if (uiState.isTriggered) {
                        "Resonance active! Tap again anytime to re-trigger"
                    } else {
                        "Open the resonance: Tap below to trigger custom vibration & hear 'মুটঠি মাহাবি' spoken aloud in Bangla"
                    },
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // The Hero Button that appears when opening the app
                ResonantButton(
                    isTriggered = uiState.isTriggered,
                    isSpeaking = uiState.isSpeaking,
                    isVibrating = uiState.isVibrating,
                    onClick = { viewModel.triggerMutthi() },
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Revealed Result Card when triggered: "mutthi mahabi" and "মুটঠি মাহাবি"
                AnimatedVisibility(
                    visible = uiState.isTriggered,
                    enter = fadeIn() + expandVertically(),
                    exit = shrinkVertically()
                ) {
                    Column {
                        MutthiDisplayCard(
                            englishText = uiState.englishText,
                            banglaText = uiState.banglaText,
                            tapCount = uiState.tapCount,
                            isSpeaking = uiState.isSpeaking,
                            isVibrating = uiState.isVibrating,
                            patternName = uiState.selectedPattern.name,
                            onSpeakClick = { viewModel.speakBanglaOnly() },
                            onVibrateClick = { viewModel.vibrateOnly() }
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                // Vibration Pattern Selector
                VibrationSelector(
                    patterns = uiState.availablePatterns,
                    selectedPattern = uiState.selectedPattern,
                    onSelectPattern = { viewModel.selectPattern(it) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Speech Tuning Controls
                SpeechControlsCard(
                    speechRate = uiState.speechRate,
                    speechPitch = uiState.speechPitch,
                    ttsStatus = uiState.ttsStatus,
                    onSpeechRateChange = { viewModel.setSpeechRate(it) },
                    onSpeechPitchChange = { viewModel.setSpeechPitch(it) }
                )

                // History Log
                if (uiState.history.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    TriggerHistoryCard(
                        history = uiState.history,
                        onClearHistory = { viewModel.clearHistory() }
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

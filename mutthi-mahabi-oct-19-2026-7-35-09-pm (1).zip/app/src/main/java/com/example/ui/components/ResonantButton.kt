package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGold
import com.example.ui.theme.PrimaryNeon
import com.example.ui.theme.PrimaryNeonGlow
import com.example.ui.theme.SecondaryCyan
import com.example.ui.theme.VioletBorder
import com.example.ui.theme.VioletDark
import com.example.ui.theme.VioletSurface

@Composable
fun ResonantButton(
    isTriggered: Boolean,
    isSpeaking: Boolean,
    isVibrating: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Tactile press scaling
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else if (isSpeaking || isVibrating) 1.05f else 1.0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "button_scale"
    )

    // Continuous subtle breathing ring animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")
    val wave1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_1"
    )

    val wave2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, delayMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_2"
    )

    val coreGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Box(
        modifier = modifier
            .size(240.dp)
            .testTag("trigger_button_container"),
        contentAlignment = Alignment.Center
    ) {
        // Animated resonant waveform circles around the button
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val maxRadius = size.width / 2

            // Wave 1
            val radius1 = 70.dp.toPx() + (maxRadius - 70.dp.toPx()) * wave1
            val alpha1 = (1f - wave1) * (if (isSpeaking || isVibrating) 0.8f else 0.35f)
            drawCircle(
                color = if (isSpeaking) SecondaryCyan.copy(alpha = alpha1) else PrimaryNeon.copy(alpha = alpha1),
                radius = radius1,
                center = center,
                style = Stroke(width = (3.dp * (1f - wave1)).toPx())
            )

            // Wave 2
            val radius2 = 70.dp.toPx() + (maxRadius - 70.dp.toPx()) * wave2
            val alpha2 = (1f - wave2) * (if (isSpeaking || isVibrating) 0.8f else 0.35f)
            drawCircle(
                color = if (isVibrating) AccentGold.copy(alpha = alpha2) else SecondaryCyan.copy(alpha = alpha2),
                radius = radius2,
                center = center,
                style = Stroke(width = (3.dp * (1f - wave2)).toPx())
            )
        }

        // Main Circular Button Body
        Box(
            modifier = Modifier
                .size(160.dp)
                .scale(scale)
                .shadow(
                    elevation = if (isPressed) 6.dp else 22.dp,
                    shape = CircleShape,
                    spotColor = if (isSpeaking) SecondaryCyan else PrimaryNeon,
                    ambientColor = PrimaryNeonGlow
                )
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            if (isSpeaking) SecondaryCyan else if (isVibrating) AccentGold else PrimaryNeon,
                            if (isSpeaking) Color(0xFF005B66) else Color(0xFF8B004F),
                            VioletSurface,
                            VioletDark
                        ),
                        radius = 260f
                    )
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
                .testTag("trigger_button"),
            contentAlignment = Alignment.Center
        ) {
            // Inner Core decorative glowing border
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                drawCircle(
                    color = Color.White.copy(alpha = 0.25f),
                    radius = (size.width / 2) - 4.dp.toPx(),
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = (if (isSpeaking) SecondaryCyan else PrimaryNeon).copy(alpha = coreGlowAlpha),
                    radius = (size.width / 2) - 12.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }

            // Core content inside button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(12.dp)
            ) {
                val icon = when {
                    isSpeaking -> Icons.Default.VolumeUp
                    isVibrating -> Icons.Default.Vibration
                    else -> Icons.Default.TouchApp
                }
                val iconTint = when {
                    isSpeaking -> SecondaryCyan
                    isVibrating -> AccentGold
                    else -> Color.White
                }

                Icon(
                    imageVector = icon,
                    contentDescription = "Trigger Mutthi Mahabi",
                    tint = iconTint,
                    modifier = Modifier.size(38.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isSpeaking) "SPEAKING" else if (isVibrating) "VIBRATING" else "TAP ME",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.8.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "মুটঠি মাহাবি",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

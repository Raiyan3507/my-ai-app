package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.PredefinedPatterns
import com.example.model.TriggerHistoryItem
import com.example.model.VibrationPattern
import com.example.service.BanglaTtsManager
import com.example.service.VibrationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MutthiUiState(
    val isTriggered: Boolean = false,
    val tapCount: Int = 0,
    val englishText: String = "mutthi mahabi",
    val banglaText: String = "মুটঠি মাহাবি",
    val selectedPattern: VibrationPattern = PredefinedPatterns.MUTTHI_SIGNATURE,
    val availablePatterns: List<VibrationPattern> = PredefinedPatterns.ALL,
    val speechRate: Float = 0.95f,
    val speechPitch: Float = 1.0f,
    val isSpeaking: Boolean = false,
    val isVibrating: Boolean = false,
    val isTtsReady: Boolean = false,
    val isBanglaAvailable: Boolean = false,
    val hasVibrator: Boolean = true,
    val isVibrationMuted: Boolean = false,
    val isVoiceMuted: Boolean = false,
    val ttsStatus: String = "Preparing audio…",
    val history: List<TriggerHistoryItem> = emptyList(),
    val lastTriggerTimeFormatted: String? = null
)

class MutthiViewModel(application: Application) : AndroidViewModel(application) {

    private val vibrationHelper = VibrationHelper(application)
    private val ttsManager = BanglaTtsManager(application) { isSuccess ->
        _uiState.update { it.copy(isTtsReady = isSuccess) }
    }

    private val _uiState = MutableStateFlow(
        MutthiUiState(
            hasVibrator = vibrationHelper.hasVibrator()
        )
    )
    val uiState: StateFlow<MutthiUiState> = _uiState.asStateFlow()

    private val dateFormat = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())

    init {
        // Observe TTS speaking state
        viewModelScope.launch {
            ttsManager.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }
        viewModelScope.launch {
            ttsManager.statusMessage.collect { status ->
                _uiState.update { it.copy(ttsStatus = status) }
            }
        }
        viewModelScope.launch {
            ttsManager.isBanglaAvailable.collect { available ->
                _uiState.update { it.copy(isBanglaAvailable = available) }
            }
        }
    }

    /**
     * Primary action: User taps the button
     * 1. Trigger custom vibration pattern
     * 2. Make the text appear ('mutthi mahabi' & 'মুটঠি মাহাবি')
     * 3. Read aloud in Bangla: 'মুটঠি মাহাবি'
     */
    fun triggerMutthi() {
        val currentState = _uiState.value
        val nowFormatted = dateFormat.format(Date())

        // 1. Vibration
        if (!currentState.isVibrationMuted) {
            vibrationHelper.playPattern(currentState.selectedPattern)
        }

        // 2. Text to Speech in Bangla: 'মুটঠি মাহাবি'
        if (!currentState.isVoiceMuted) {
            ttsManager.speakBangla(
                text = currentState.banglaText,
                speechRate = currentState.speechRate,
                pitch = currentState.speechPitch
            )
        }

        // 3. Update state: text appears, tap count increments, history entry added
        val newHistoryItem = TriggerHistoryItem(
            id = System.currentTimeMillis(),
            timestamp = nowFormatted,
            patternName = currentState.selectedPattern.name,
            textSpoken = currentState.banglaText
        )

        _uiState.update { state ->
            state.copy(
                isTriggered = true,
                tapCount = state.tapCount + 1,
                lastTriggerTimeFormatted = nowFormatted,
                isVibrating = true,
                history = listOf(newHistoryItem) + state.history.take(19)
            )
        }

        // Temporary visual vibrating pulse state
        viewModelScope.launch {
            val duration = currentState.selectedPattern.timings.sum()
            delay(duration.coerceAtLeast(600L))
            _uiState.update { it.copy(isVibrating = false) }
        }
    }

    fun speakBanglaOnly() {
        val state = _uiState.value
        ttsManager.speakBangla(
            text = state.banglaText,
            speechRate = state.speechRate,
            pitch = state.speechPitch
        )
    }

    fun vibrateOnly() {
        val pattern = _uiState.value.selectedPattern
        vibrationHelper.playPattern(pattern)
        viewModelScope.launch {
            _uiState.update { it.copy(isVibrating = true) }
            delay(pattern.timings.sum().coerceAtLeast(500L))
            _uiState.update { it.copy(isVibrating = false) }
        }
    }

    fun selectPattern(pattern: VibrationPattern) {
        _uiState.update { it.copy(selectedPattern = pattern) }
        // Quick preview buzz
        if (!_uiState.value.isVibrationMuted) {
            vibrationHelper.playPattern(pattern)
        }
    }

    fun setSpeechRate(rate: Float) {
        _uiState.update { it.copy(speechRate = rate) }
    }

    fun setSpeechPitch(pitch: Float) {
        _uiState.update { it.copy(speechPitch = pitch) }
    }

    fun toggleVibrationMute() {
        _uiState.update { it.copy(isVibrationMuted = !it.isVibrationMuted) }
    }

    fun toggleVoiceMute() {
        _uiState.update { it.copy(isVoiceMuted = !it.isVoiceMuted) }
    }

    fun resetState() {
        ttsManager.stop()
        vibrationHelper.cancel()
        _uiState.update { it.copy(isTriggered = false, isVibrating = false, isSpeaking = false) }
    }

    fun clearHistory() {
        _uiState.update { it.copy(history = emptyList(), tapCount = 0) }
    }

    override fun onCleared() {
        super.onCleared()
        vibrationHelper.cancel()
        ttsManager.shutdown()
    }
}

package com.example.service

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.model.VibrationPattern

class VibrationHelper(private val context: Context) {

    private val tag = "VibrationHelper"

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to get vibrator service", e)
            null
        }
    }

    fun hasVibrator(): Boolean {
        return try {
            vibrator?.hasVibrator() == true
        } catch (e: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    fun playPattern(pattern: VibrationPattern) {
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val hasAmplitudeControl = vib.hasAmplitudeControl()
                val effect = if (hasAmplitudeControl && pattern.amplitudes.isNotEmpty() &&
                    pattern.amplitudes.size == pattern.timings.size
                ) {
                    VibrationEffect.createWaveform(pattern.timings, pattern.amplitudes, -1)
                } else {
                    VibrationEffect.createWaveform(pattern.timings, -1)
                }
                vib.vibrate(effect)
            } else {
                vib.vibrate(pattern.timings, -1)
            }
        } catch (e: Exception) {
            Log.e(tag, "Error triggering vibration", e)
            try {
                // Fallback to simple vibration
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    vib.vibrate(300)
                }
            } catch (fallbackEx: Exception) {
                Log.e(tag, "Fallback vibration failed", fallbackEx)
            }
        }
    }

    fun cancel() {
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            Log.e(tag, "Error cancelling vibration", e)
        }
    }
}

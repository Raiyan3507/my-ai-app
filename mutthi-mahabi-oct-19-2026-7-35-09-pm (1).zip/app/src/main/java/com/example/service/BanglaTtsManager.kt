package com.example.service

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class BanglaTtsManager(
    private val context: Context,
    private val onInitComplete: ((Boolean) -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private val tag = "BanglaTtsManager"
    private var tts: TextToSpeech? = null

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isBanglaAvailable = MutableStateFlow(false)
    val isBanglaAvailable: StateFlow<Boolean> = _isBanglaAvailable.asStateFlow()

    private val _statusMessage = MutableStateFlow("Initializing voice engine…")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var activeLocale: Locale = Locale("bn", "BD")

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts
            if (engine != null) {
                // Try Bangladesh Bangla first, then India Bangla, then generic bn
                val banglaCandidates = listOf(
                    Locale("bn", "BD"),
                    Locale("bn", "IN"),
                    Locale("bn")
                )

                var resolvedLocale: Locale? = null
                for (loc in banglaCandidates) {
                    val availability = engine.isLanguageAvailable(loc)
                    if (availability >= TextToSpeech.LANG_AVAILABLE) {
                        resolvedLocale = loc
                        break
                    }
                }

                if (resolvedLocale != null) {
                    engine.language = resolvedLocale
                    activeLocale = resolvedLocale
                    _isBanglaAvailable.value = true
                    _statusMessage.value = "Bangla voice ready (${resolvedLocale.displayLanguage})"
                } else {
                    // Try setting anyway as Android TTS engine often downloads or supports phonetics
                    val defaultBangla = Locale("bn", "BD")
                    val result = engine.setLanguage(defaultBangla)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        _isBanglaAvailable.value = false
                        _statusMessage.value = "Bangla voice pack not pre-installed (using fallback)"
                    } else {
                        _isBanglaAvailable.value = true
                        _statusMessage.value = "Bangla voice ready"
                    }
                }

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        Log.w(tag, "TTS onError code: $errorCode")
                    }
                })

                _isReady.value = true
                onInitComplete?.invoke(true)
            }
        } else {
            _isReady.value = false
            _statusMessage.value = "Voice engine unavailable"
            onInitComplete?.invoke(false)
        }
    }

    fun speakBangla(
        text: String,
        speechRate: Float = 0.95f,
        pitch: Float = 1.0f,
        utteranceId: String = "mutthi_${System.currentTimeMillis()}"
    ) {
        val engine = tts ?: return
        try {
            engine.stop()
            engine.setSpeechRate(speechRate.coerceIn(0.5f, 2.0f))
            engine.setPitch(pitch.coerceIn(0.5f, 2.0f))

            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } catch (e: Exception) {
            Log.e(tag, "Error speaking text: $text", e)
            _isSpeaking.value = false
        }
    }

    fun stop() {
        try {
            tts?.stop()
            _isSpeaking.value = false
        } catch (e: Exception) {
            Log.e(tag, "Error stopping TTS", e)
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.e(tag, "Error shutting down TTS", e)
        }
    }
}

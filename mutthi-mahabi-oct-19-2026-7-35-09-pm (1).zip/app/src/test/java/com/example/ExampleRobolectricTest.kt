package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.PredefinedPatterns
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Mutthi Mahabi", appName)

        val banglaTitle = context.getString(R.string.title_bangla)
        assertEquals("মুটঠি মাহাবি", banglaTitle)
    }

    @Test
    fun `verify predefined vibration patterns`() {
        val patterns = PredefinedPatterns.ALL
        assertTrue(patterns.isNotEmpty())

        val signature = PredefinedPatterns.MUTTHI_SIGNATURE
        assertEquals("mutthi_sig", signature.id)
        assertTrue(signature.timings.isNotEmpty())

        val bol = PredefinedPatterns.BANGLA_BOL
        assertNotNull(bol)
        assertTrue(bol.timings.size >= 4)
    }
}
